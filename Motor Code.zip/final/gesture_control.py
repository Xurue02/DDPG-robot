import cv2
from handdetector import HandDetector
import numpy as np
import math
import serial
import time

arduino_port = '/dev/cu.usbmodem12401'
baud_rate = 9600 
ser = serial.Serial(arduino_port, baud_rate, timeout=1) # Wait for the connection to establish

camera = cv2.VideoCapture(0) 
camera.set(3, 1280)
camera.set(cv2.CAP_PROP_FPS, 30)
detector = HandDetector()    
handopen = 0
handclose = 0
handleft = 0
handright = 0
handup = 0
handdown = 0
start = 0
l = [0,0,0,0,0,0,1]
aaa = 0
while True:    
    frame, img = camera.read()   
    if frame == True:
        img = cv2.flip(img,1)
    img = detector.findHands(img) 
    lmList, bbox ,center, motion, section= detector.findPosition(img) 
    fingers = detector.fingersUp()
    ##print(center)   
    #print(handopen)
    cv2.imshow("camera", img)
    key=cv2.waitKey(1)
    if key==27:
        break
    #  +收线， -放线
    reset = 1
    
    move = 0.4/(3*math.pi)*537.6
    l1 = 0;l2 = 0;l3 = 0;l4 = 0;l5 = 0;l6 = 0
    if section == 1:
        if  motion == 'right':
            l1 = move*math.cos(7/12*math.pi)
            l2 = move*math.cos(3/4*math.pi)
            l3 = move*math.cos(1/12*math.pi)
            l4 = move*math.cos(5/12*math.pi)
            l5 = move*math.cos(11/12*math.pi)
            l6 = move*math.cos(1/4*math.pi)
            reset = 0
        elif motion == 'left':
            l1 = -move*math.cos(7/12*math.pi)
            l2 = -move*math.cos(3/4*math.pi)
            l3 = -move*math.cos(1/12*math.pi)
            l4 = -move*math.cos(5/12*math.pi)
            l5 = -move*math.cos(11/12*math.pi)
            l6 = -move*math.cos(1/4*math.pi)
            reset = 0
        elif motion == 'forward':
            l1 = move*math.cos(1/12*math.pi)
            l2 = move*math.cos(3/4*math.pi)
            l3 = move*math.cos(7/12*math.pi)
            l4 = move*math.cos(1/12*math.pi)
            l5 = move*math.cos(7/12*math.pi)
            l6 = move*math.cos(3/4*math.pi)
            reset = 0
        elif motion == 'backward':
            l1 = -move*math.cos(1/12*math.pi)
            l2 = -move*math.cos(3/4*math.pi)
            l3 = -move*math.cos(7/12*math.pi)
            l4 = -move*math.cos(1/12*math.pi)
            l5 = -move*math.cos(7/12*math.pi)
            l6 = -move*math.cos(3/4*math.pi)
            reset = 0
        
    elif section == 2:
        if  motion == 'right':
            l1 = 0
            l2 = 0
            l3 = 0
            l4 = move*math.cos(5/12*math.pi)
            l5 = move*math.cos(11/12*math.pi)
            l6 = move*math.cos(1/4*math.pi)
            reset = 0
        elif motion == 'left':
            l1 = 0
            l2 = 0
            l3 = 0
            l4 = -move*math.cos(5/12*math.pi)
            l5 = -move*math.cos(11/12*math.pi)
            l6 = -move*math.cos(1/4*math.pi)
            reset = 0
        elif motion == 'forward':
            l1 = 0
            l2 = 0
            l3 = 0
            l4 = move*math.cos(1/12*math.pi)
            l5 = move*math.cos(7/12*math.pi)
            l6 = move*math.cos(3/4*math.pi)
            reset = 0
        elif motion == 'backward':
            l1 = 0
            l2 = 0
            l3 = 0
            l4 = -move*math.cos(1/12*math.pi)
            l5 = -move*math.cos(7/12*math.pi)
            l6 = -move*math.cos(3/4*math.pi)
            reset = 0
    l[0] = int(l[0]+l1)
    l[1] = int(l[1]+l2)
    l[2] = int(l[2]+l3)
    l[3] = int(l[3]+l4)
    l[4] = int(l[4]+l5)
    l[5] = int(l[5]+l6)

    if reset == 1:
        l=[0,0,0,0,0,0,1]
    l[6] = reset
    ll = str(l)
    aaa+=1

    ser.write((ll + "\n").encode())
    print("Transmitted targets:")
    print(ll)    
    print(ser.readline().decode('utf-8'))
    print(ser.readline().decode('utf-8'))
    print(ser.readline().decode('utf-8'))