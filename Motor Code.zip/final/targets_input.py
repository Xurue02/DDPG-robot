import serial
import time
import ast
import re
import matplotlib.pyplot as plt

arduino_port = '/dev/cu.usbmodem12401'
baud_rate = 115200 
# Create the serial connection
ser = serial.Serial(arduino_port, baud_rate, timeout=1)
# Wait for the connection to establish
time.sleep(2)
# Input the targets here
target = "[-610,447,163,-700,711,447]"

ser.write((target + "\n").encode())
list1 = []
start_time = time.time()
while time.time() - start_time < 3:  # Read for 5 seconds
    data = ser.readline().decode()  # Read a line from the serial port
    if data:  # Check if data is not empty
        list1 += [data] 
        print(data)  # Print the received data
    # time.sleep(0.1)  # Add a small delay to avoid high CPU usage if needed

# Close the serial connection
ser.close()

# Convert the string to a numerical array
target_list = ast.literal_eval(target)
# Calculate the absolute values
absolute_values = [abs(value) for value in target_list]
print("targets received:", absolute_values)

# Use regular expression to find numbers that directly follow the pattern "pos[number]:"
positions = re.findall(r'pos\d+:(\d+)', data)
# Convert found strings to integers
position_list = [int(pos) for pos in positions]
print("final pulse achieved:", position_list)

# Calculate element-wise error percentage
try: 
    error_percentage = [abs((m - a) / a) * 100 for a, m in zip(position_list, absolute_values)]

except ZeroDivisionError as e:
    error_percentage = [abs((m - a) / (a+0.0001)) * 100 for a, m in zip(position_list, absolute_values)]

print("Individual error for each motor:", error_percentage)
total_sum = sum(error_percentage)
print("Total error sum:", total_sum)

# Initialize lists for each pos
pos1, pos2, pos3, pos4, pos5, pos6 = [], [], [], [], [], []

# Iterate through the list to process each string
for entry in list1:
    if 'pos1:' in entry:
        # Split the string by spaces and iterate through the parts
        parts = entry.split()
        for part in parts:
            if 'pos1:' in part:
                pos1.append(int(part.split(':')[1]))
            elif 'pos2:' in part:
                pos2.append(int(part.split(':')[1]))
            elif 'pos3:' in part:
                pos3.append(int(part.split(':')[1]))
            elif 'pos4:' in part:
                pos4.append(int(part.split(':')[1]))
            elif 'pos5:' in part:
                pos5.append(int(part.split(':')[1]))
            elif 'pos6:' in part:
                pos6.append(int(part.split(':')[1]))

# Creating subplots
fig, axs = plt.subplots(6, 1, figsize=(10, 10))
target_list = ast.literal_eval(target)
abs_targets = [abs(item) for item in target_list] # Example target values for pos1 through pos6
# Setting up each subplot with a target line
for i, ax in enumerate(axs):
    pos_data = [pos1, pos2, pos3, pos4, pos5, pos6][i]
    target = abs_targets[i]
    ax.plot(pos_data, marker='o', linestyle='-')
    ax.axhline(y=target, color='r', linestyle='--')  # Adding a horizontal line for the target
    ax.set_title(f'pos{i+1} with target {target}')
    ax.grid(True)


# Setting up each subplot
axs[0].plot(pos1, marker='o', linestyle='-')
axs[0].set_title('pos1')
axs[0].grid(True)

axs[1].plot(pos2, marker='o', linestyle='-')
axs[1].set_title('pos2')
axs[1].grid(True)

axs[2].plot(pos3, marker='o', linestyle='-')
axs[2].set_title('pos3')
axs[2].grid(True)

axs[3].plot(pos4, marker='o', linestyle='-')
axs[3].set_title('pos4')
axs[3].grid(True)

axs[4].plot(pos5, marker='o', linestyle='-')
axs[4].set_title('pos5')
axs[4].grid(True)

axs[5].plot(pos6, marker='o', linestyle='-')
axs[5].set_title('pos6')
axs[5].grid(True)

# Adjust layout to make room for the titles and prevent overlap
plt.tight_layout()

# Show plot
plt.show()

