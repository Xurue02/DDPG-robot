'''
Left stick x-axis: axis 0
Left stick y-axis: axis 1
Right stick x-axis: axis 2
Right stick y-axis: axis 3

"X" button: button 0
"◯" button: button 1
"□" button: button 2
"△" button: button 3

"↑" button: button 11
"↓" button: button 12
"←" button: button 13
"→" button: button 14

"L1" button: button 9
"R1" button: button 10

'''
import numpy as np
import math
import pygame
import sys
import serial
import time

# Initialise serial port
arduino_port = '/dev/cu.usbmodem12401'
baud_rate = 9600 
ser = serial.Serial(arduino_port, baud_rate, timeout=1) # Wait for the connection to establish
time.sleep(2)  # Wait for the connection to establish

# Initialize Pygame and the joystick subsystem
pygame.init()
pygame.joystick.init()

# Wait for a joystick to be connected
while pygame.joystick.get_count() == 0:
    print("Please connect a joystick.")
    pygame.time.wait(1000)  # Wait for 1 second and check again
    pygame.joystick.init()  # Re-initialize the joystick module

# Initialize the first joystick
joystick = pygame.joystick.Joystick(0)
joystick.init()

print(f"Detected joystick: {joystick.get_name()}")
print(f"Number of axes: {joystick.get_numaxes()}")
print(f"Number of buttons: {joystick.get_numbuttons()}")

# Initilise parameters
l = [0,0,0,0,0,0,1]
aaa = 0 
axis_values = [0,0,0,0]
reset = 0
move = 0.4/(3*math.pi)*537.6
prev_motion = 'null'
current_motion = 'null'

while True:
    section = 0
    motion = 'idle'        
    l1 = 0;l2 = 0;l3 = 0;l4 = 0;l5 = 0;l6 = 0

    pygame.event.pump()  # Process event queue
    section1_forward = joystick.get_button(11)
    section1_backward = joystick.get_button(12)
    section1_left = joystick.get_button(13)
    section1_right = joystick.get_button(14)
    section1_results = [section1_forward, section1_backward, section1_left, section1_right]
    print(section1_results)

    section2_forward = joystick.get_button(3)
    section2_backward = joystick.get_button(0)
    section2_left = joystick.get_button(2)
    section2_right = joystick.get_button(1)
    section2_results = [section2_forward, section2_backward, section2_left, section2_right]
    print(section2_results)

    if section1_forward > 0:
        section = 1
        motion = 'forward'
        current_motion = 'forward1'

    if section1_backward > 0:
        section = 1
        motion = 'backward'
        current_motion = 'backward1'

    if section1_left > 0:
        section = 1
        motion = 'left'
        current_motion = 'left1'

    if section1_right > 0:
        section = 1
        motion = 'right'
        current_motion = 'right1'

    if section2_forward > 0:
        section = 2
        motion = 'forward'
        current_motion = 'forward2'

    if section2_backward > 0:
        section = 2
        motion = 'backward'
        current_motion = 'backward2'

    if section2_left > 0:
        section = 2
        motion = 'left'
        current_motion = 'left2'

    if section2_right > 0:
        section = 2
        motion = 'right'
        current_motion = 'right2'

    if section == 0:
        pass
    elif section == 1:
        if  motion == 'right':
            l1 = move*math.cos(7/12*math.pi)
            l2 = move*math.cos(3/4*math.pi)
            l3 = move*math.cos(1/12*math.pi)
            l4 = move*math.cos(5/12*math.pi)
            l5 = move*math.cos(11/12*math.pi)
            l6 = move*math.cos(1/4*math.pi)

        elif motion == 'left':
            l1 = -move*math.cos(7/12*math.pi)
            l2 = -move*math.cos(3/4*math.pi)
            l3 = -move*math.cos(1/12*math.pi)
            l4 = -move*math.cos(5/12*math.pi)
            l5 = -move*math.cos(11/12*math.pi)
            l6 = -move*math.cos(1/4*math.pi)

        elif motion == 'forward':
            l1 = move*math.cos(1/12*math.pi)
            l2 = move*math.cos(3/4*math.pi)
            l3 = move*math.cos(7/12*math.pi)
            l4 = move*math.cos(1/12*math.pi)
            l5 = move*math.cos(7/12*math.pi)
            l6 = move*math.cos(3/4*math.pi)

        elif motion == 'backward':
            l1 = -move*math.cos(1/12*math.pi)
            l2 = -move*math.cos(3/4*math.pi)
            l3 = -move*math.cos(7/12*math.pi)
            l4 = -move*math.cos(1/12*math.pi)
            l5 = -move*math.cos(7/12*math.pi)
            l6 = -move*math.cos(3/4*math.pi)

    elif section == 2:
        if  motion == 'right':
            l1 = 0
            l2 = 0
            l3 = 0
            l4 = move*math.cos(5/12*math.pi)
            l5 = move*math.cos(11/12*math.pi)
            l6 = move*math.cos(1/4*math.pi)

        elif motion == 'left':
            l1 = 0
            l2 = 0
            l3 = 0
            l4 = -move*math.cos(5/12*math.pi)
            l5 = -move*math.cos(11/12*math.pi)
            l6 = -move*math.cos(1/4*math.pi)

        elif motion == 'forward':
            l1 = 0
            l2 = 0
            l3 = 0
            l4 = 0
            l5 = 0
            l6 = move*math.cos(3/4*math.pi)

        elif motion == 'backward':
            l1 = 0
            l2 = 0
            l3 = 0
            l4 = 0
            l5 = 0
            l6 = -move*math.cos(3/4*math.pi)

    if current_motion != prev_motion:
        l=[0,0,0,0,0,0,1]
        print("Motor inputs have been reset because robot motion has been changed")

    reset = joystick.get_button(10)
    if reset == 1:
        l=[0,0,0,0,0,0,1]
        print("Motor inputs have been reset")
    exit_button = joystick.get_button(9)
    if exit_button == 1:
        print("L1 button pressed. Exiting.")
        pygame.quit()
        sys.exit()           


    l[0] = int(l[0]+l1)
    l[1] = int(l[1]+l2)
    l[2] = int(l[2]+l3)
    l[3] = int(l[3]+l4)
    l[4] = int(l[4]+l5)
    l[5] = int(l[5]+l6)
    
    ll = str(l)     
    print("Transmitted targets:")
    print(ll)    
    ser.write((ll + "\n").encode())


    print(ser.readline().decode('utf-8'))
    print(ser.readline().decode('utf-8'))
    print(ser.readline().decode('utf-8'))

    prev_motion = current_motion
    l[6] = reset
