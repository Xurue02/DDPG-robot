import cv2
import mediapipe as mp


class HandDetector:
    """
    使用mediapipe库查找手。导出地标像素格式。添加了额外的功能。
    如查找方式，许多手指向上或两个手指之间的距离。而且提供找到的手的边界框信息。
    """
    def __init__(self, mode=False, maxHands=2, detectionCon=0.5, minTrackCon = 0.5):
        """
        :param mode: 在静态模式下，对每个图像进行检测
        :param maxHands: 要检测的最大手数
        :param detectionCon: 最小检测置信度
        :param minTrackCon: 最小跟踪置信度
        """
        self.mode = mode
        self.maxHands = maxHands
        self.modelComplex = False
        self.detectionCon = detectionCon
        self.minTrackCon = minTrackCon

		# 初始化手部识别模型
        self.mpHands = mp.solutions.hands
        self.hands = self.mpHands.Hands(self.mode, self.maxHands, self.modelComplex,
                                        self.detectionCon, self.minTrackCon)
        self.mpDraw = mp.solutions.drawing_utils	# 初始化绘图器
        self.tipIds = [4, 8, 12, 16, 20]			# 指尖列表
        self.fingers = []
        self.lmList = []

        self.start = 0
        self.stop = 0
        self.started = 0
        self.stopped = 1
        self.section = 0
        self.section1 = 0
        self.section2 = 0
        self.motion = 'stop'

    def findHands(self, img, draw=True):

        imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB) # 将传入的图像由BGR模式转标准的Opencv模式——RGB模式，
        self.results = self.hands.process(imgRGB)

        if self.results.multi_hand_landmarks:
            for handLms in self.results.multi_hand_landmarks:
                if draw:
                    self.mpDraw.draw_landmarks(img, handLms,
                                               self.mpHands.HAND_CONNECTIONS)
        return img

    def findPosition(self, img, handNo=0, draw=True):


        xList = []
        yList = []
        bbox = []
        bboxInfo =[]
        center = []
        self.lmList = []
        cv2.line(img,(0,250),(1200,250),(255,0,0),3)
        cv2.line(img,(0,450),(1200,450),(255,0,0),3)
        cv2.line(img,(400,0),(400,700),(255,0,0),3)
        cv2.line(img,(800,0),(800,700),(255,0,0),3)
        self.motion = 'stop'

        if self.results.multi_hand_landmarks:
            myHand = self.results.multi_hand_landmarks[handNo]
            for id, lm in enumerate(myHand.landmark):
                h, w, c = img.shape
                px, py = int(lm.x * w), int(lm.y * h)
                xList.append(px)
                yList.append(py)
                self.lmList.append([px, py])
                if draw:
                    cv2.circle(img, (px, py), 5, (255, 0, 255), cv2.FILLED)
            xmin, xmax = min(xList), max(xList)
            ymin, ymax = min(yList), max(yList)
            boxW, boxH = xmax - xmin, ymax - ymin
            bbox = xmin, ymin, boxW, boxH
            cx, cy = bbox[0] + (bbox[2] // 2), \
                     bbox[1] + (bbox[3] // 2)
            center = [cx,cy]
            bboxInfo = {"id": id, "bbox": bbox,"center": (cx, cy)}
            color = [0,0,255]
            if draw:
                cv2.rectangle(img, (bbox[0] - 20, bbox[1] - 20),
                              (bbox[0] + bbox[2] + 20, bbox[1] + bbox[3] + 20),
                              color, 2)
                cv2.rectangle(img, (center[0]-3,center[1]-3),(center[0]+3,center[1]+3),(0,255,0),2)

                fingers = self.fingersUp()

                tx = ''
                if center[0] <=800 and center[0] >= 400 and center[1] <= 450 and center[1] >=250 and sum(fingers)>2 and self.started == 0:
                    self.start+=1
                    tx = 'starting'
                
                else: 
                    self.start = 0
                if self.start >=30:
                    self.stop = 0
                    self.started = 1
                    self.stopped =0

                #print(self.start)

                if self.started == 1:
                    if fingers[0] == 0 and fingers[1] == 1 and fingers[2] == 0 and fingers[3] == 0 and fingers[4] == 0:
                        self.section1+=1
                        self.section2 = 0
                        tx = 'section 1 checking'
                    elif fingers[0] == 0 and fingers[1] == 1 and fingers[2] == 1 and fingers[3] == 0 and fingers[4] == 0:
                        self.section2+=1
                        self.section1 = 0
                        tx = 'section 2 checking'
                    
                    if fingers[0] == 0 and fingers[1] == 0 and fingers[2] == 0 and fingers[3] == 1 and fingers[4] == 0:
                        self.section1+=1
                        self.section2 = 0
                        tx = 'section 1 checking'
                    elif fingers[0] == 0 and fingers[1] == 0 and fingers[2] == 1 and fingers[3] == 1 and fingers[4] == 0:
                        self.section2+=1
                        self.section1 = 0
                        tx = 'section 2 checking'
                    
                    if self.section1>=30 and fingers[0] == 0 and fingers[1] == 1 and fingers[2] == 0 and fingers[3] == 0 and fingers[4] == 0:
                        tx = 'section 1 begin'
                        self.section = 1
                    
                    elif self.section2 >=30 and fingers[0] == 0 and fingers[1] == 1 and fingers[2] == 1 and fingers[3] == 0 and fingers[4] == 0:
                        tx = 'section 2 begin'
                        self.section = 2




                if self.started == 1 and sum(fingers)>2:
                    tx = 'started'
                    if center[0] > 800 and center[1]<=450 and center[1]>=250:
                        tx = 'moving right'   
                        self.motion = 'right'         
                    elif center[0] < 400 and center[1]<=450 and center[1]>=250:
                        tx = 'moving left'  
                        self.motion = 'left'          
                    elif center[1] > 450 and center[0] <= 800 and center[0] >= 400:
                        tx = 'moving forward'
                        self.motion = 'forward'
                    elif center[1] < 250 and center[0] <= 800 and center[0] >= 400:
                        tx = 'moving backward'
                        self.motion = 'backward'
                if sum(fingers)==0 and self.stopped == 0 and center[0] <=800 and center[0] >= 400 and center[1] <= 450 and center[1] >=250:
                    self.stop+=1
                    tx = 'stopping'
                else:
                    self.stop = 0
                if self.stop>=30:
                    self.start = 0                   
                    self.started = 0
                    self.stopped = 1  
                if self. stopped == 1 and sum(fingers) == 0:
                    tx = 'stopped'
                    

                font=cv2.FONT_HERSHEY_SIMPLEX
                cv2.putText(img, '{} '.format(tx), (center[0]-8,center[1]-6), font, 2, (0, 255, 255), 3)

        return self.lmList, bbox, center, self.motion, self.section

    def fingersUp(self):
        fingers = []

        if self.results.multi_hand_landmarks:
            # Thumb

            if self.lmList[self.tipIds[1]][0] > self.lmList[self.tipIds[1] - 1][0] :
                fingers.append(1)
            else:
                fingers.append(0)
            for id in range(1, 5):
                if self.lmList[self.tipIds[id]][1] < self.lmList[self.tipIds[id] - 2][1]:
                    fingers.append(1)
                else:
                    fingers.append(0)

        return fingers

            
